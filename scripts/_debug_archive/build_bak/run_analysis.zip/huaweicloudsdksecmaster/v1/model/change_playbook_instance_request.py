# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ChangePlaybookInstanceRequest:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'project_id': 'str',
        'workspace_id': 'str',
        'instance_id': 'str',
        'body': 'OperationPlaybookInfo'
    }

    attribute_map = {
        'project_id': 'project_id',
        'workspace_id': 'workspace_id',
        'instance_id': 'instance_id',
        'body': 'body'
    }

    def __init__(self, project_id=None, workspace_id=None, instance_id=None, body=None):
        r"""ChangePlaybookInstanceRequest

        The model defined in huaweicloud sdk

        :param project_id: 项目ID
        :type project_id: str
        :param workspace_id: 工作空间ID
        :type workspace_id: str
        :param instance_id: 剧本实例ID
        :type instance_id: str
        :param body: Body of the ChangePlaybookInstanceRequest
        :type body: :class:`huaweicloudsdksecmaster.v1.OperationPlaybookInfo`
        """
        
        

        self._project_id = None
        self._workspace_id = None
        self._instance_id = None
        self._body = None
        self.discriminator = None

        self.project_id = project_id
        self.workspace_id = workspace_id
        self.instance_id = instance_id
        if body is not None:
            self.body = body

    @property
    def project_id(self):
        r"""Gets the project_id of this ChangePlaybookInstanceRequest.

        项目ID

        :return: The project_id of this ChangePlaybookInstanceRequest.
        :rtype: str
        """
        return self._project_id

    @project_id.setter
    def project_id(self, project_id):
        r"""Sets the project_id of this ChangePlaybookInstanceRequest.

        项目ID

        :param project_id: The project_id of this ChangePlaybookInstanceRequest.
        :type project_id: str
        """
        self._project_id = project_id

    @property
    def workspace_id(self):
        r"""Gets the workspace_id of this ChangePlaybookInstanceRequest.

        工作空间ID

        :return: The workspace_id of this ChangePlaybookInstanceRequest.
        :rtype: str
        """
        return self._workspace_id

    @workspace_id.setter
    def workspace_id(self, workspace_id):
        r"""Sets the workspace_id of this ChangePlaybookInstanceRequest.

        工作空间ID

        :param workspace_id: The workspace_id of this ChangePlaybookInstanceRequest.
        :type workspace_id: str
        """
        self._workspace_id = workspace_id

    @property
    def instance_id(self):
        r"""Gets the instance_id of this ChangePlaybookInstanceRequest.

        剧本实例ID

        :return: The instance_id of this ChangePlaybookInstanceRequest.
        :rtype: str
        """
        return self._instance_id

    @instance_id.setter
    def instance_id(self, instance_id):
        r"""Sets the instance_id of this ChangePlaybookInstanceRequest.

        剧本实例ID

        :param instance_id: The instance_id of this ChangePlaybookInstanceRequest.
        :type instance_id: str
        """
        self._instance_id = instance_id

    @property
    def body(self):
        r"""Gets the body of this ChangePlaybookInstanceRequest.

        :return: The body of this ChangePlaybookInstanceRequest.
        :rtype: :class:`huaweicloudsdksecmaster.v1.OperationPlaybookInfo`
        """
        return self._body

    @body.setter
    def body(self, body):
        r"""Sets the body of this ChangePlaybookInstanceRequest.

        :param body: The body of this ChangePlaybookInstanceRequest.
        :type body: :class:`huaweicloudsdksecmaster.v1.OperationPlaybookInfo`
        """
        self._body = body

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ChangePlaybookInstanceRequest):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
