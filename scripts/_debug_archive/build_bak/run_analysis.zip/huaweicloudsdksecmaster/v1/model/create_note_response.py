# coding: utf-8

from huaweicloudsdkcore.sdk_response import SdkResponse
from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class CreateNoteResponse(SdkResponse):

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'code': 'str',
        'message': 'str',
        'success': 'bool',
        'data': 'NotesDetail'
    }

    attribute_map = {
        'code': 'code',
        'message': 'message',
        'success': 'success',
        'data': 'data'
    }

    def __init__(self, code=None, message=None, success=None, data=None):
        r"""CreateNoteResponse

        The model defined in huaweicloud sdk

        :param code: **参数解释**: 错误码 **取值范围**: 不涉及
        :type code: str
        :param message: **参数解释**: 错误描述 **取值范围**: 不涉及
        :type message: str
        :param success: 是否请求成功
        :type success: bool
        :param data: 
        :type data: :class:`huaweicloudsdksecmaster.v1.NotesDetail`
        """
        
        super().__init__()

        self._code = None
        self._message = None
        self._success = None
        self._data = None
        self.discriminator = None

        if code is not None:
            self.code = code
        if message is not None:
            self.message = message
        if success is not None:
            self.success = success
        if data is not None:
            self.data = data

    @property
    def code(self):
        r"""Gets the code of this CreateNoteResponse.

        **参数解释**: 错误码 **取值范围**: 不涉及

        :return: The code of this CreateNoteResponse.
        :rtype: str
        """
        return self._code

    @code.setter
    def code(self, code):
        r"""Sets the code of this CreateNoteResponse.

        **参数解释**: 错误码 **取值范围**: 不涉及

        :param code: The code of this CreateNoteResponse.
        :type code: str
        """
        self._code = code

    @property
    def message(self):
        r"""Gets the message of this CreateNoteResponse.

        **参数解释**: 错误描述 **取值范围**: 不涉及

        :return: The message of this CreateNoteResponse.
        :rtype: str
        """
        return self._message

    @message.setter
    def message(self, message):
        r"""Sets the message of this CreateNoteResponse.

        **参数解释**: 错误描述 **取值范围**: 不涉及

        :param message: The message of this CreateNoteResponse.
        :type message: str
        """
        self._message = message

    @property
    def success(self):
        r"""Gets the success of this CreateNoteResponse.

        是否请求成功

        :return: The success of this CreateNoteResponse.
        :rtype: bool
        """
        return self._success

    @success.setter
    def success(self, success):
        r"""Sets the success of this CreateNoteResponse.

        是否请求成功

        :param success: The success of this CreateNoteResponse.
        :type success: bool
        """
        self._success = success

    @property
    def data(self):
        r"""Gets the data of this CreateNoteResponse.

        :return: The data of this CreateNoteResponse.
        :rtype: :class:`huaweicloudsdksecmaster.v1.NotesDetail`
        """
        return self._data

    @data.setter
    def data(self, data):
        r"""Sets the data of this CreateNoteResponse.

        :param data: The data of this CreateNoteResponse.
        :type data: :class:`huaweicloudsdksecmaster.v1.NotesDetail`
        """
        self._data = data

    def to_dict(self):
        import warnings
        warnings.warn("CreateNoteResponse.to_dict() is deprecated and no longer maintained, "
                      "use to_json_object() to get the response content.", DeprecationWarning)
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, CreateNoteResponse):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
